#include <bits/stdc++.h>
using namespace std;

int main ()
{
    double n;
    cin>> n;
    if(n==0)
    {
        cout<<"Not Numeric constant"<<endl;
    }
    else
    {
        cout<<"Numeric constant"<<endl;
    }


return 0;
}
